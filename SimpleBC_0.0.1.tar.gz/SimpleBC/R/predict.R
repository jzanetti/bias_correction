


predict_bc_model <- function(fcst, covariants, model, scaler) {
  data = prep_data_for_predicting(fcst, covariants, scaler)
}